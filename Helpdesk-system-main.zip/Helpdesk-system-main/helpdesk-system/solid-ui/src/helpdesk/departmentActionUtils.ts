import { useDispatch } from "react-redux";
import { closePopup } from "@solidxai/core-ui";

export function useCloseDepartmentPopup() {
  const dispatch = useDispatch();
  return {
    closeOnly: () => dispatch(closePopup()),
    closeAndReload: () => {
      dispatch(closePopup());
      window.location.reload();
    },
  };
}

export function parseApiPayload(json: unknown): Record<string, unknown> {
  if (json && typeof json === "object" && "data" in json) {
    const data = (json as { data?: unknown }).data;
    if (data && typeof data === "object") {
      return data as Record<string, unknown>;
    }
  }
  return (json as Record<string, unknown>) ?? {};
}
