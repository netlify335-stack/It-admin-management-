import { SolidViewLayoutManager } from "@solidxai/core-ui";

export const departmentEditHandler = async (event: any) => {
  const { viewMetadata, formData } = event;
  const layoutManager = new SolidViewLayoutManager(viewMetadata.layout);
  const recordId = formData?.id;
  const status = formData?.status ?? "InActive";
  const isActive = status === "Active";

  if (!recordId) {
    layoutManager.updateFormButtonByAction("DepartmentActivateById", {
      visible: false,
    });
    layoutManager.updateFormButtonByAction("DepartmentDeactivateById", {
      visible: false,
    });
  } else if (isActive) {
    layoutManager.updateFormButtonByAction("DepartmentActivateById", {
      visible: false,
    });
    layoutManager.updateFormButtonByAction("DepartmentDeactivateById", {
      visible: true,
    });
  } else {
    layoutManager.updateFormButtonByAction("DepartmentActivateById", {
      visible: true,
    });
    layoutManager.updateFormButtonByAction("DepartmentDeactivateById", {
      visible: false,
    });
  }

  return {
    layoutChanged: true,
    dataChanged: false,
    newLayout: layoutManager.getLayout(),
  };
};
