export const ticketCriticalHandler = async (event: any) => {
  const { modifiedField, modifiedFieldValue, formData } = event;

  if (modifiedField === "priority" && modifiedFieldValue === "Critical") {
    console.log(
      `🚨 ALERT: High Priority Ticket Logged! Title: ${formData?.title ?? "(no title)"}`,
    );
  }

  return { layoutChanged: false, dataChanged: false };
};
