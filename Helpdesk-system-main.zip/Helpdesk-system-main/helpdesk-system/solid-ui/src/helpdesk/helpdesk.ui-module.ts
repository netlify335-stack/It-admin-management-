import {
  type SolidUiModule,
  ExtensionComponentTypes,
  ExtensionFunctionTypes,
} from "@solidxai/core-ui";
import { TicketKanbanCardWidget } from "./TicketKanbanCardWidget";
import { ticketCriticalHandler } from "./ticketCriticalHandler";
import DepartmentActivateById from "./DepartmentActivateById";
import DepartmentDeactivateById from "./DepartmentDeactivateById";
import { departmentEditHandler } from "./departmentEditHandler";

const helpdeskUiModule: SolidUiModule = {
  name: "helpdesk",
  extensionComponents: [
    {
      name: "TicketKanbanCardWidget",
      component: TicketKanbanCardWidget,
      type: ExtensionComponentTypes.kanbanCardWidget,
    },
    {
      name: "DepartmentActivateById",
      component: DepartmentActivateById,
      type: ExtensionComponentTypes.formAction,
    },
    {
      name: "DepartmentDeactivateById",
      component: DepartmentDeactivateById,
      type: ExtensionComponentTypes.formAction,
    },
  ],
  extensionFunctions: [
    {
      name: "ticketCriticalHandler",
      fn: ticketCriticalHandler,
      type: ExtensionFunctionTypes.onFieldChange,
    },
    {
      name: "departmentEditHandler",
      fn: departmentEditHandler,
      type: ExtensionFunctionTypes.onFormLayoutLoad,
    },
  ],
};

export default helpdeskUiModule;
