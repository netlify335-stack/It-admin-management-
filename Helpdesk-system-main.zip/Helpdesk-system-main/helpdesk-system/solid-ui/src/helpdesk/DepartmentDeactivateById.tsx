import { useState } from "react";
import { SolidConfirmDialog, env, useSession } from "@solidxai/core-ui";
import { parseApiPayload, useCloseDepartmentPopup } from "./departmentActionUtils";

type Props = {
  formData?: { id?: number };
};

export function DepartmentDeactivateById({ formData }: Props) {
  const { data: session } = useSession();
  const [loading, setLoading] = useState(false);
  const { closeOnly, closeAndReload } = useCloseDepartmentPopup();

  const handleDeactivate = async () => {
    if (!formData?.id || loading) {
      return;
    }
    setLoading(true);
    try {
      const apiUrl = env("API_URL", "http://localhost:3000");
      const token = session?.user?.accessToken;
      const response = await fetch(
        `${apiUrl}/api/department/deactivate/${formData.id}`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        },
      );
      const body = parseApiPayload(await response.json().catch(() => ({})));
      if (!response.ok) {
        throw new Error(String(body?.message || "Deactivation failed"));
      }
      closeAndReload();
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "Failed to deactivate department.";
      window.alert(message);
      setLoading(false);
    }
  };

  return (
    <SolidConfirmDialog
      open
      title="Deactivate department?"
      message="This sets the department back to InActive."
      confirmLabel={loading ? "Deactivating…" : "Deactivate"}
      cancelLabel="Cancel"
      onConfirm={handleDeactivate}
      onCancel={closeOnly}
    />
  );
}

export default DepartmentDeactivateById;
