import React from "react";

export const TicketKanbanCardWidget = ({ rowData }: any) => {
  return (
    <div style={{ padding: "12px", border: "1px solid #e2e8f0", borderRadius: "6px", background: "white" }}>
      <h4 style={{ margin: "0 0 8px 0", fontSize: "16px" }}>{rowData.title || 'No Title'}</h4>
      <div style={{ fontSize: "12px", color: "#64748b" }}>Status: {rowData.status}</div>
      <div style={{ fontSize: "12px", color: "#64748b" }}>Priority: {rowData.priority}</div>
    </div>
  );
};
