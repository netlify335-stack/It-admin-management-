import { useState } from "react";
import { SolidConfirmDialog, env, useSession } from "@solidxai/core-ui";
import { parseApiPayload, useCloseDepartmentPopup } from "./departmentActionUtils";

type Props = {
  formData?: { id?: number };
};

export function DepartmentActivateById({ formData }: Props) {
  const { data: session } = useSession();
  const [loading, setLoading] = useState(false);
  const { closeOnly, closeAndReload } = useCloseDepartmentPopup();

  const handleActivate = async () => {
    if (!formData?.id || loading) {
      return;
    }
    setLoading(true);
    try {
      const apiUrl = env("API_URL", "http://localhost:3000");
      const token = session?.user?.accessToken;
      const response = await fetch(
        `${apiUrl}/api/department/activate/${formData.id}`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        },
      );
      const body = parseApiPayload(await response.json().catch(() => ({})));
      if (!response.ok) {
        throw new Error(String(body?.message || "Activation failed"));
      }
      if (body.hostsSkipped && body.manualHostsLine) {
        window.alert(
          `Department activated.\n\nOptional — add to your hosts file (Windows: run Notepad as Administrator):\n\n${body.manualHostsLine}\n\nPortal: ${body.portalUrl ?? ""}`,
        );
      }
      closeAndReload();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to activate department.";
      window.alert(message);
      setLoading(false);
    }
  };

  return (
    <SolidConfirmDialog
      open
      title="Activate department?"
      message="This marks the department Active. Local DNS (hosts file) is optional on Windows; status will update either way."
      confirmLabel={loading ? "Activating…" : "Activate"}
      cancelLabel="Cancel"
      onConfirm={handleActivate}
      onCancel={closeOnly}
    />
  );
}

export default DepartmentActivateById;
