import { Injectable } from '@nestjs/common';
import { InjectEntityManager } from '@nestjs/typeorm';
import { ModuleRef  } from "@nestjs/core";
import { EntityManager } from 'typeorm';
import { CRUDService } from '@solidxai/core';
import { Ticket } from '../entities/ticket.entity';
import { TicketRepository } from '../repositories/ticket.repository';

@Injectable()
export class TicketService extends CRUDService<Ticket>{
  constructor(
    @InjectEntityManager("default")
    readonly entityManager: EntityManager,
    readonly repo: TicketRepository,
    readonly moduleRef: ModuleRef,
      
 ) {
   super(entityManager, repo, 'ticket', 'helpdesk', moduleRef);
 }
}