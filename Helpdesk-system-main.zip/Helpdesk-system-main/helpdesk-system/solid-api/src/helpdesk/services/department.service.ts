import {
  BadRequestException,
  Injectable,
  NotAcceptableException,
} from '@nestjs/common';
import { InjectEntityManager } from '@nestjs/typeorm';
import { ModuleRef } from '@nestjs/core';
import { EntityManager } from 'typeorm';
import { CRUDService } from '@solidxai/core';
import { Department } from '../entities/department.entity';
import { DepartmentRepository } from '../repositories/department.repository';
import { HostsFileDnsManager } from './hosts-file-dns.manager';

@Injectable()
export class DepartmentService extends CRUDService<Department> {
  private readonly dnsManager = new HostsFileDnsManager();

  constructor(
    @InjectEntityManager('default')
    readonly entityManager: EntityManager,
    readonly repo: DepartmentRepository,
    readonly moduleRef: ModuleRef,
  ) {
    super(entityManager, repo, 'department', 'helpdesk', moduleRef);
  }

  private resolveHostname(dept: Department): string {
    const base = process.env.HELPDESK_BASE_DOMAIN || 'helpdesk.ticket.com';
    const prefix = dept.portalHostPrefix?.trim();
    if (!prefix) {
      return base;
    }
    if (prefix.includes('.')) {
      return prefix;
    }
    return `${prefix}.${base}`;
  }

  private shouldSkipHostsFile(): boolean {
    const flag = (process.env.HELPDESK_SKIP_HOSTS ?? '').toLowerCase();
    return flag === '1' || flag === 'true' || flag === 'yes';
  }

  private manualHostsLine(hostname: string): string {
    return `127.0.0.1  ${hostname}  # solidx-helpdesk-dns`;
  }

  private async applyHostsEntry(hostname: string, mode: 'create' | 'remove') {
    if (this.shouldSkipHostsFile()) {
      return { hostsSkipped: true as const };
    }
    try {
      if (mode === 'create') {
        await this.dnsManager.createHostEntry(hostname);
      } else {
        await this.dnsManager.removeHostEntry(hostname);
      }
      return { hostsSkipped: false as const };
    } catch {
      // No sudo / Windows / WSL split: still allow activation; UI shows manualHostsLine
      return { hostsSkipped: true as const };
    }
  }

  async activateDepartment(id: number) {
    const dept = await this.findOne(id, {});
    if (!dept) {
      throw new BadRequestException('Department not found');
    }
    if (dept.status === 'Active') {
      throw new NotAcceptableException('Department is already active');
    }

    const hostname = this.resolveHostname(dept);
    const hostsResult = await this.applyHostsEntry(hostname, 'create');

    dept.status = 'Active';
    await this.repo.save(dept);

    const port = process.env.HELPDESK_PORTAL_PORT || '3002';
    const manualHostsLine = this.manualHostsLine(hostname);
    return {
      message: hostsResult.hostsSkipped
        ? 'Department activated (add the hosts line manually — see manualHostsLine).'
        : 'Department activated successfully',
      hostname,
      portalUrl: `http://${hostname}:${port}`,
      hostsSkipped: hostsResult.hostsSkipped,
      manualHostsLine: hostsResult.hostsSkipped ? manualHostsLine : undefined,
    };
  }

  async deactivateDepartment(id: number) {
    const dept = await this.findOne(id, {});
    if (!dept) {
      throw new BadRequestException('Department not found');
    }
    if (dept.status !== 'Active') {
      throw new NotAcceptableException('Department is not active');
    }

    const hostname = this.resolveHostname(dept);
    const hostsResult = await this.applyHostsEntry(hostname, 'remove');

    dept.status = 'InActive';
    await this.repo.save(dept);

    return {
      message: hostsResult.hostsSkipped
        ? 'Department deactivated (remove the hosts line manually if you added one).'
        : 'Department deactivated successfully',
      hostsSkipped: hostsResult.hostsSkipped,
      manualHostsLine: hostsResult.hostsSkipped
        ? this.manualHostsLine(hostname)
        : undefined,
    };
  }
}
