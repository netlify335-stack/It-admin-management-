import { promises as fs } from 'fs';

const HOSTS_PATH = '/etc/hosts';
const MARKER = '# solidx-helpdesk-dns';

export class HostsFileDnsManager {
  async createHostEntry(hostname: string, ip = '127.0.0.1'): Promise<void> {
    const content = await fs.readFile(HOSTS_PATH, 'utf8');
    const line = `${ip}\t${hostname} ${MARKER}`;
    if (content.includes(`${hostname} ${MARKER}`) || content.includes(`${hostname}\t`)) {
      return;
    }
    await fs.writeFile(HOSTS_PATH, `${content.trimEnd()}\n${line}\n`);
  }

  async removeHostEntry(hostname: string): Promise<void> {
    const content = await fs.readFile(HOSTS_PATH, 'utf8');
    const filtered = content
      .split('\n')
      .filter((line) => !(line.includes(hostname) && line.includes(MARKER)))
      .join('\n');
    await fs.writeFile(HOSTS_PATH, `${content.endsWith('\n') ? filtered : `${filtered}\n`}`);
  }
}
