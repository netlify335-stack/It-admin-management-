import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Ticket } from './entities/ticket.entity';
import { TicketService } from './services/ticket.service';
import { TicketController } from './controllers/ticket.controller';
import { TicketRepository } from './repositories/ticket.repository';
import { Category } from './entities/category.entity';
import { CategoryService } from './services/category.service';
import { CategoryController } from './controllers/category.controller';
import { CategoryRepository } from './repositories/category.repository';
import { Department } from './entities/department.entity';
import { DepartmentService } from './services/department.service';
import { DepartmentController } from './controllers/department.controller';
import { DepartmentRepository } from './repositories/department.repository';

@Module({
    imports: [
        TypeOrmModule.forFeature([Ticket]),
        TypeOrmModule.forFeature([Category]),
        TypeOrmModule.forFeature([Department]),
    ],
    controllers: [TicketController, CategoryController, DepartmentController],
    providers: [
        TicketService,
        TicketRepository,
        CategoryService,
        CategoryRepository,
        DepartmentService,
        DepartmentRepository,
    ],
})
export class HelpdeskModule {}
