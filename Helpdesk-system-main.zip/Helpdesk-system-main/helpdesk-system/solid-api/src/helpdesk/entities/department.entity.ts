import { CommonEntity } from '@solidxai/core';
import { Entity, Column } from 'typeorm';

@Entity('department')
export class Department extends CommonEntity {
    @Column({ type: "varchar", unique: true, nullable: true })
    name: string;

    @Column({ type: "text", nullable: true })
    description: string;

    @Column({ type: "varchar", nullable: true, default: 'InActive' })
    status: string;

    @Column({ type: "varchar", unique: true, nullable: true })
    portalHostPrefix: string;
}
