import { CommonEntity, User } from '@solidxai/core';
import { Entity, Column, JoinColumn, ManyToOne } from 'typeorm';
import { Category } from 'src/helpdesk/entities/category.entity'

@Entity('ticket')
export class Ticket extends CommonEntity {
    @Column({ type: "varchar" })
    title: string;

    @Column({ type: "text" })
    description: string;

    @Column({ type: "varchar", nullable: true, default: "Open" })
    status: string = "Open";

    @Column({ type: "varchar", nullable: true, default: "Medium" })
    priority: string = "Medium";

    @ManyToOne(() => Category, { onDelete: "CASCADE", nullable: true })
    @JoinColumn()
    category: Category;

    @ManyToOne(() => User, { onDelete: "CASCADE", nullable: true })
    @JoinColumn()
    assignee: User;

    @ManyToOne(() => User, { onDelete: "CASCADE", nullable: true })
    @JoinColumn()
    reporter: User;
}