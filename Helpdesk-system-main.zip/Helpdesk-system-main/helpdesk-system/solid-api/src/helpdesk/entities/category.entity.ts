import { CommonEntity } from '@solidxai/core';
import { Entity, Column, JoinColumn, ManyToOne, OneToMany } from 'typeorm';
import { Department } from 'src/helpdesk/entities/department.entity';
import { Ticket } from 'src/helpdesk/entities/ticket.entity'

@Entity('category')
export class Category extends CommonEntity {
    @Column({ type: "varchar" })
    name: string;

    @OneToMany(() => Ticket, ticket => ticket.category, { cascade: true })
    Tickets: Ticket[];

    @ManyToOne(() => Department, { onDelete: "CASCADE", nullable: true })
    @JoinColumn()
    department: Department;
}