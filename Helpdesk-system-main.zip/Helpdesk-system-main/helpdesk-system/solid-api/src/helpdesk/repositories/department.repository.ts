import { Injectable } from '@nestjs/common';
import { SecurityRuleRepository, SolidBaseRepository, RequestContextService } from '@solidxai/core';
import { DataSource } from 'typeorm';
import { InjectDataSource } from '@nestjs/typeorm';
import { Department } from '../entities/department.entity';

@Injectable()
export class DepartmentRepository extends SolidBaseRepository<Department> {
  constructor(
    @InjectDataSource('default')
    readonly dataSource: DataSource,
    readonly requestContextService: RequestContextService,
    readonly securityRuleRepository: SecurityRuleRepository,
  ) {
    super(Department, dataSource, requestContextService, securityRuleRepository);
  }
}
