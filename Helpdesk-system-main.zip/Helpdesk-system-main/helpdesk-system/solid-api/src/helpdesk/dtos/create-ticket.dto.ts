import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';
import { IsNotEmpty, IsOptional, IsInt } from 'class-validator';

export class CreateTicketDto {
    @IsNotEmpty()
    @IsString()
    @ApiProperty()
    title: string;

    @IsNotEmpty()
    @IsString()
    @ApiProperty()
    description: string;

    @IsOptional()
    @IsString()
    @ApiProperty()
    status: string = "Open";

    @IsOptional()
    @IsString()
    @ApiProperty()
    priority: string = "Medium";

    @IsOptional()
    @IsInt()
    @ApiProperty()
    categoryId: number;

    @IsString()
    @IsOptional()
    @ApiProperty()
    categoryUserKey: string;

    @IsOptional()
    @IsInt()
    @ApiProperty()
    assigneeId: number;

    @IsString()
    @IsOptional()
    @ApiProperty()
    assigneeUserKey: string;

    @IsOptional()
    @IsInt()
    @ApiProperty()
    reporterId: number;

    @IsString()
    @IsOptional()
    @ApiProperty()
    reporterUserKey: string;
}