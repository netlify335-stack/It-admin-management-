import { IsInt,IsOptional, IsString, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateTicketDto {
    @IsOptional()
    @IsInt()
    id: number;

    @IsNotEmpty()
    @IsOptional()
    @IsString()
    @ApiProperty()
    title: string;

    @IsNotEmpty()
    @IsOptional()
    @IsString()
    @ApiProperty()
    description: string;

    @IsOptional()
    @IsString()
    @ApiProperty()
    status: string;

    @IsOptional()
    @IsString()
    @ApiProperty()
    priority: string;

    @IsOptional()
    @IsInt()
    @ApiProperty()
    categoryId: number;

    @IsString()
    @IsOptional()
    @ApiProperty()
    categoryUserKey: string;

    @IsOptional()
    @IsInt()
    @ApiProperty()
    assigneeId: number;

    @IsString()
    @IsOptional()
    @ApiProperty()
    assigneeUserKey: string;

    @IsOptional()
    @IsInt()
    @ApiProperty()
    reporterId: number;

    @IsString()
    @IsOptional()
    @ApiProperty()
    reporterUserKey: string;
}