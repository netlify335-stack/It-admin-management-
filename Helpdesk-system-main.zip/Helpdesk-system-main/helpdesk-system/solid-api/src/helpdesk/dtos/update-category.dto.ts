import { IsInt,IsOptional, IsString, IsNotEmpty, ValidateNested, IsArray } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { UpdateTicketDto } from 'src/helpdesk/dtos/update-ticket.dto';

export class UpdateCategoryDto {
    @IsOptional()
    @IsInt()
    id: number;

    @IsNotEmpty()
    @IsOptional()
    @IsString()
    @ApiProperty()
    name: string;

    @IsOptional()
    @ApiProperty({ description: "Tickets" })
    @IsArray()
    @ValidateNested({ each: true })
    @Type(() => UpdateTicketDto)
    Tickets: UpdateTicketDto[];

    @IsOptional()
    @IsArray()
    @ApiProperty({ description: "Tickets" })
    TicketsIds: number[];

    @IsString()
    @IsOptional()
    @ApiProperty({ description: "Tickets" })
    TicketsCommand: string;

    @IsOptional()
    @IsInt()
    @ApiProperty()
    departmentId: number;

    @IsString()
    @IsOptional()
    @ApiProperty()
    departmentUserKey: string;
}