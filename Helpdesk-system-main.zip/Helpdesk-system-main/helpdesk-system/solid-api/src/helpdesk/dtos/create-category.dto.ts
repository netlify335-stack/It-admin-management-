import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';
import { IsNotEmpty, IsInt, IsOptional, ValidateNested, IsArray } from 'class-validator';
import { Type } from 'class-transformer';
import { UpdateTicketDto } from 'src/helpdesk/dtos/update-ticket.dto';

export class CreateCategoryDto {
    @IsNotEmpty()
    @IsString()
    @ApiProperty()
    name: string;

    @IsOptional()
    @ApiProperty({ description: "Tickets" })
    @IsArray()
    @ValidateNested({ each: true })
    @Type(() => UpdateTicketDto)
    Tickets: UpdateTicketDto[];

    @IsOptional()
    @IsArray()
    @ApiProperty({ description: "Tickets" })
    TicketsIds: number[];

    @IsString()
    @IsOptional()
    @ApiProperty({ description: "Tickets" })
    TicketsCommand: string;

    @IsOptional()
    @IsInt()
    @ApiProperty()
    departmentId: number;

    @IsString()
    @IsOptional()
    @ApiProperty()
    departmentUserKey: string;
}