# SolidX Internal IT Helpdesk - Build Guide

This document is the end-to-end guide for building an **Internal IT Helpdesk & Ticketing System** on SolidX. It covers bootstrapping the app, modeling the domain in Module Builder, customizing list/form/kanban views, IAM (roles, permissions, security rules), and department activation workflow.

**Repository layout**

| Path | Purpose |
| --- | --- |
| `helpdesk-system/solid-api/` | NestJS API, generated controllers, `module-metadata/helpdesk/helpdesk-metadata.json` |
| `helpdesk-system/solid-ui/` | React UI, extensions in `src/helpdesk/` |
| `solidx_helpdesk_architecture.md` | RBAC, data model, and lifecycle (companion to this guide) |

**URLs (default dev)**

- UI: `http://localhost:3001`
- API: `http://localhost:3000`

---

## Introduction

SolidX is used here to show:

- **Module Builder** - Department, Category, Ticket models and relations  
- **Layout Editor** - List, form (with workflow status), Kanban  
- **IAM** - Employee vs Helpdesk Agent vs Super Admin  
- **Record-level security** - employees see only their own tickets  
- **Extension points** - Kanban card widget, `onFieldChange` handler, activate/deactivate department  

At the end you have a working helpdesk: employees log tickets, agents triage on a Kanban board, and a department can be marked **Active** with an optional local DNS entry for demo hostnames (e.g. `it.helpdesk.ticket.com`).

---

## Prerequisites

- **Node.js** v22 or higher  
- **PostgreSQL** running locally or in Docker  
- Familiarity with the [SolidX Setup](https://docs.solidxai.com/docs/tutorial/school-fees-portal/solidx-setup) tutorial if this is your first project  

---

Start by runnning a Postgres instance, to start run these commands:

```bash
docker run -d \
  --name SolidX_ticket_DB \
  -e POSTGRES_USER=app_builder \
  -e POSTGRES_PASSWORD=password123 \
  -e POSTGRES_DB=ticket_app_db \
  -p 5432:5432 \
  -v solidx_ticketdata:/var/lib/postgresql/data \
  postgres:17
```

**Expected output:** `docker ps` shows container `SolidX_ticket_DB` on port 5432:

![Docker PostgreSQL container running](docs/images/docker-postgres-setup.png)

## Phase 1 - Bootstrap the application

### 1.1 Create the project

```bash
npx @solidxai/solidctl@latest create-app
```

Interactive prompts:

- Follow the steps 
- Choose **PostgreSQL**  
- Enter host, port, user, password, and database name  

![Setup Folder](docs/images/setup-folder.png)

### 1.2 Build, seed, and run

```bash
cd helpdesk-system
npx @solidxai/solidctl@latest build
npx @solidxai/solidctl@latest seed
```

Start the backend server
```bash
cd helpdesk-system/solid-api
npm run solidx:dev
```

Start development (from `solid-ui`; API typically starts on port 3000):

```bash
cd helpdesk-system/solid-ui
npm run solidx:dev
```

Open **http://localhost:3001**. Complete Super Admin registration if prompted, then sign in as `sa`.

![SolidX Homepage](docs/images/solidx-homepage.png)

### 1.3 Verify core platform

Confirm you can open **Module Builder**, **Layout Builder**, and **IAM**. The helpdesk module will be added in the next phase.


---

## Phase 2 - Domain modeling (Module Builder)

Create one module: **Helpdesk**. Add three models in this order - SolidX requires the **target** model to exist before you add a relation to it.
![Helpdesk Module](docs/images/helpdesk-module.png)

### 2.1 Department

| Field | Type | Notes |
| --- | --- | --- |
| `name` | Short Text | Required, unique, **Is User Key** |
| `description` | Long Text | Optional |
| `status` | Selection Static | Values `InActive`, `Active`; default `InActive` |
| `portalHostPrefix` | Short Text | Unique; e.g. `it` → hostname `it.helpdesk.ticket.com` |

Do **not** add the Categories relation manually yet; it is created when you define Category with **Create Inverse**.

### 2.2 Category

| Field | Type | Notes |
| --- | --- | --- |
| `name` | Short Text | Required; **Is User Key** (see 2.4) |
| `department` | Relation many-to-one | Co-module Helpdesk, co-model Department; **Create Inverse** → inverse name `Categories` |

### 2.3 Ticket

| Field | Type | Notes |
| --- | --- | --- |
| `title` | Short Text | Required |
| `description` | Rich Text | Required |
| `status` | Selection Static | `Open`, `InProgress`, `Resolved`, `Closed`; default `Open` |
| `priority` | Selection Static | `Low`, `Medium`, `High`, `Critical`; default `Medium` |
| `category` | Relation many-to-one | Co-model Category; inverse `Tickets` |
| `assignee` | Relation many-to-one | Co-module **Solid Core**, co-model **User** |
| `reporter` | Relation many-to-one | Co-module **Solid Core**, co-model **User** |

### 2.4 Generate models and sync metadata

For each model, use **Generate Code** in Model Builder, then from the project root:

```bash
cd helpdesk-system
npx @solidxai/solidctl@latest build
npx @solidxai/solidctl@latest seed
```

Restart `npm run solidx:dev` if the API was already running.

![Models](docs/images/models.png)

### 2.5 User key on Category (required for Employee ticket form)

Relation autocomplete/search uses the related model’s **user key** field. If `category.name` is not a user key, employees get an API error when opening the Category dropdown on a ticket, for example:

`column entity.undefined does not exist`

**Fix:** In `helpdesk-metadata.json`, on the category model’s `name` field, set:

```json
"isUserKey": true
```

Department `name` should also be a user key (usually already set if unique). Re-seed:

```bash
npx @solidxai/solidctl@latest seed
```

Module Builder sometimes hides **Is User Key** when **Unique** is unchecked on Category; editing metadata + seed is the reliable workaround.

---

## Phase 3 - Views and UI extensions

SolidX generates default list/tree/form views. Customize them for a helpdesk workflow.

Reference: [View Customizations](https://docs.solidxai.com/docs/tutorial/school-fees-portal/view-customizations).

### 3.1 Ticket form - workflow status indicator

**Layout Builder → Views → `ticket-form-view` → Edit JSON.**

At the form root `attrs`:

```json
{
  "label": "IT Ticket",
  "workflowField": "status",
  "workflowFieldUpdateEnabled": true
}
```

Use the metadata field name `status` (lowercase). This adds the clickable status stepper on the form header.

![Status Header](docs/images/status-header.png)

### 3.2 Ticket Kanban view

Create or edit `ticket-kanban-view` (type **kanban**, model **Ticket**).

Example layout root:

```json
{
  "type": "kanban",
  "attrs": {
    "groupBy": "status",
    "draggable": true,
    "allowedViews": ["list", "kanban"]
  },
  "children": [
    {
      "type": "card",
      "attrs": {
        "cardWidget": "TicketKanbanCardWidget"
      }
    }
  ]
}
```

On **`ticket-list-view`**, add to `attrs`:

```json
"allowedViews": ["list", "kanban"]
```

Without this, the list view does not show the Kanban toggle.

### 3.3 Kanban card widget (code)

**File:** `solid-ui/src/helpdesk/TicketKanbanCardWidget.tsx`  
Implement a small card (title, priority, category, etc.).

**Register in** `solid-ui/src/helpdesk/helpdesk.ui-module.ts` - use `extensionComponents`: 

```typescript
import {
  type SolidUiModule,
  ExtensionComponentTypes,
  ExtensionFunctionTypes,
} from "@solidxai/core-ui";
import { TicketKanbanCardWidget } from "./TicketKanbanCardWidget";

const helpdeskUiModule: SolidUiModule = {
  name: "helpdesk",
  extensionComponents: [
    {
      name: "TicketKanbanCardWidget",
      component: TicketKanbanCardWidget,
      type: ExtensionComponentTypes.kanbanCardWidget,
    },
  ],
  extensionFunctions: [],
};

export default helpdeskUiModule;
```

Restart the UI dev server after adding the file.

![Kanban Board](docs/images/kanban-board-view.png)

**If Kanban does not appear:** Gear → **Clear cache**, hard refresh, confirm `allowedViews` on both list and kanban views.

### 3.4 Menus (sidebar)

Helpdesk menu items in `helpdesk-metadata.json` must include a **`roles`** array, for example:

```json
{
  "displayName": "Ticket",
  "name": "ticket-menu-item",
  "roles": ["Employee", "Helpdesk Agent"]
}
```

| Menu item | Typical roles |
| --- | --- |
| Home | Employee, Helpdesk Agent |
| Ticket | Employee, Helpdesk Agent |
| Category | Helpdesk Agent |
| Department | Helpdesk Agent, Admin |

Without `roles`, `MenuItemMetadataController.findUserMenus` returns no items for Employee/Agent - the sidebar looks empty even when permissions exist. Re-seed after changes.

---

## Phase 4 - Security and IAM

Architecture summary: `solidx_helpdesk_architecture.md`.

### 4.1 Roles (seeded in metadata)

Defined under `"roles"` in `helpdesk-metadata.json`. After any edit:

```bash
cd helpdesk-system
npx @solidxai/solidctl@latest seed
```

Restart API, **Clear cache** in UI, log out and back in.

#### Employee

| Area | Access |
| --- | --- |
| **Ticket** | `create`, `findOne`, `findMany`, `update`, `partialUpdate` |
| **Category** | `findOne`, `findMany` only (dropdown on ticket form) |
| **Department** | None |
| **Platform** | Menus, views, auth, chatter, settings, etc. |

#### Helpdesk Agent

| Area | Access |
| --- | --- |
| **Ticket** | Full CRUD + bulk |
| **Category** | Full CRUD |
| **Department** | `findOne`, `findMany`, `activateDepartment`, `deactivateDepartment` |
| **Platform** | Employee stack + import/export |

Agents do **not** get `DepartmentController.create` in v1 - departments are created by Super Admin (see Phase 5 and Design scope).

#### Super Admin

All permissions by default; creates departments and manages IAM.

### 4.2 Security rule - Employee ticket isolation

In `"securityRules"`:

```json
{
  "name": "model:ticket-role:Employee",
  "description": "Employees can only read and update tickets they created",
  "roleUserKey": "Employee",
  "modelMetadataUserKey": "ticket",
  "securityRuleConfig": {
    "filters": {
      "createdBy": { "$eq": "$activeUserId" }
    }
  }
}
```

**UI equivalent:** IAM → Security Rules → Ticket → role Employee → `createdBy` equals current user.

Helpdesk Agent has **no** ticket security rule → sees all tickets.

![Employee Security](docs/images/employee-security.png)

### 4.3 Test users (seeded)

| Role | Username | Email | Password |
| --- | --- | --- | --- |
| Employee | `employee1` | `employee1@helpdesk.local` | `Helpdesk@123` |
| Helpdesk Agent | `agent1` | `agent1@helpdesk.local` | `Helpdesk@123` |
| Super Admin | `sa` | (setup email) | `Admin@3214$` (default seed) |

New users also receive the **Internal User** role automatically from SolidX signup.

If seed skips existing users, create them under **IAM → Users** and assign roles manually.

---

## Phase 5 - Custom handler (Critical priority)

### 5.1 Handler implementation

**File:** `solid-ui/src/helpdesk/ticketCriticalHandler.ts`

```typescript
export const ticketCriticalHandler = async (event: any) => {
  const { modifiedField, modifiedFieldValue, formData } = event;

  if (modifiedField === "priority" && modifiedFieldValue === "Critical") {
    console.log(
      `🚨 ALERT: High Priority Ticket Logged! Title: ${formData?.title ?? "(no title)"}`,
    );
  }

  return { layoutChanged: false, dataChanged: false };
};
```

### 5.2 Register in UI module

```typescript
import { ticketCriticalHandler } from "./ticketCriticalHandler";

extensionFunctions: [
  {
    name: "ticketCriticalHandler",
    fn: ticketCriticalHandler,
    type: ExtensionFunctionTypes.onFieldChange,
  },
],
```

### 5.3 Bind on ticket form layout

On `ticket-form-view` layout root:

```json
"onFieldChange": "ticketCriticalHandler"
```

**Test:** Log in as `agent1` → open a ticket → F12 → Console → set **Priority** to **Critical** → see the log line.

This is a **browser-side** hook (`onFieldChange`), not a server job. Production use would call email, Slack, or a queue.

<h2>🔴 Facing some error, still in Build</h2>

---

## Phase 6 - Department activation

This phase covers activating a department so it can be fully functional.

### 6.1 Role split (who does what)

| Helpdesk |
| --- |
| Super Admin creates **Department** (`InActive`) |
| Helpdesk Agent **activates** (`status`) |

Activation is done on the **department edit form**. The agent opens an existing row (e.g. **IT Support**), then clicks **Activate Department** in the form header.

### 6.2 Prepare demo data (Super Admin, in the UI)

1. Log in as **sa**.  
2. **Helpdesk → Department → Create**.  
3. Example values:  
   - **Name:** `IT Support`  
   - **Status:** `InActive` (default)  
4. Save.  
5. **Helpdesk → Category → Create** - link each category to **IT Support**.

### 6.3 Agent activation steps

1. Log in as **agent1** / `Helpdesk@123`.  
2. **Helpdesk → Department** → click **IT Support**.  
3. On the edit form, click **Activate Department**.  
4. Confirm in the dialog.  
5. **Status** becomes **Active**.

**Note on the Activation Link:**
The success message might display a portal link (e.g., `http://it.helpdesk.ticket.com:3002/`). However, in this v1 implementation, there is **no separate portal running on port 3002**. All users share the same SolidX UI on port `3001`. This link is shown to mirror the Institute model but requires additional setup (like Nginx/DNS) for a separate portal.

**Note on `/etc/hosts` / DNS:** 
Automated DNS/hosts configuration is not officially supported and writing to `/etc/hosts` automatically is not working on Windows even with WSL. To bypass the hosts update failure locally, set `HELPDESK_SKIP_HOSTS=true` in `solid-api/.env`. You can then manually update your `hosts` file if necessary.

![Department Activation](docs/images/department-activation.png)

---

## End-to-end test script

Use this before submitting:

1. **employee1** - Create ticket, select **Category** (no crash), save. List shows only own tickets. No Category/Department admin menus.  
2. **agent1** - Ticket **Kanban**, drag status. **Category** list - create/edit.  
3. **sa** - Create department and categories in the UI.  
4. **agent1** - Open department → **Activate Department** → status **Active**.  
5. **agent1** - Ticket form → Priority **Critical** → console alert.  
6. **IAM** - Screenshot security rule for Employee.

---

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| Empty sidebar for employee/agent | Menu items missing `roles` | Add roles in metadata → `seed` → clear cache → re-login |
| Category field crashes for employee | `category.name` not user key | `"isUserKey": true` → `seed` |
| Kanban widget not found | Wrong registration key | `extensionComponents` + `kanbanCardWidget` type |
| Department list empty for agent | No rows created | **sa** creates department in UI first |
| No Activate button | New form, or wrong handler API | Open **existing** row; use `updateFormButtonByAction`; restart UI |
| Stuck empty popup after activate | Popup slice left open | Fixed in code (`closePopup`); hard-refresh if needed |
| `EACCES` on `/etc/hosts` | API not privileged | Status still updates; use `HELPDESK_SKIP_HOSTS=true` or ignore - paste hosts line manually on Windows |
| Seed fails Department permissions | Controller not built | `npm run build` in `solid-api` then `seed` |
| Activate succeeds but URL does not resolve | Windows vs WSL hosts | Edit **Windows** hosts file or use Codespaces |

---

