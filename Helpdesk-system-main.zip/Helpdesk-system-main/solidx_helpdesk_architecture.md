# SolidX IT Helpdesk — Architecture

Overview of roles, data model, UI flows, and extension points for the **Internal IT Helpdesk** in `helpdesk-system/`. Pair with `solidx_helpdesk_tutorial.md` for step-by-step build instructions.

---

## 1. Core idea

Employees log IT tickets in a shared SolidX app. Helpdesk agents triage and resolve work on a Kanban board. Super Admins set up **departments**; agents **activate** a department when it should go live (status + optional local DNS), following the same *create vs activate* split as [Institute Onboarding](https://docs.solidxai.com/docs/tutorial/school-fees-portal/end-to-end-implementation/institute_onboarding) and [Activate Institute](https://docs.solidxai.com/docs/tutorial/school-fees-portal/end-to-end-implementation/activate_institute) in the School Fees portal.

---

## 2. Roles and access

```mermaid
graph TD
    SA[Super Admin] --> AG[Helpdesk Agent]
    SA --> EM[Employee]
```

### Super Admin

- Full platform access (Module Builder, IAM, all data).
- **Creates** department records (`InActive` by default).
- Manages users and roles.

### Helpdesk Agent

- **Tickets:** full CRUD; sees **all** tickets (no record rule).
- **Categories:** full CRUD.
- **Departments:** `findOne`, `findMany`, `activateDepartment`, `deactivateDepartment` — does **not** create departments in v1.
- **Activation:** opens an existing department form → **Activate Department** / **Deactivate Department** (header actions).

### Employee

- **Tickets:** create, read, update **own** tickets only (record rule on `createdBy`).
- **Categories:** read-only (for the category dropdown on the ticket form).
- **Departments:** no menu access.
- Does not see other employees’ tickets.

---

## 3. Data model (Helpdesk module)

```mermaid
erDiagram
    DEPARTMENT ||--o{ CATEGORY : contains
    CATEGORY ||--o{ TICKET : categorizes
    USER ||--o{ TICKET : reporter
    USER ||--o{ TICKET : assignee

    DEPARTMENT {
        string name UK
        text description
        string status
        string portalHostPrefix UK
    }

    CATEGORY {
        string name
        int departmentId FK
    }

    TICKET {
        string title
        text description
        string status
        string priority
        int categoryId FK
        int assigneeId FK
        int reporterId FK
    }
```

| Model | Purpose |
| --- | --- |
| **Department** | Org unit; `status` `InActive` / `Active`; `portalHostPrefix` for demo hostname |
| **Category** | Classifies tickets; belongs to one department |
| **Ticket** | Issue/request; workflow on `status`; links to category and users |

**Metadata:** `helpdesk-system/solid-api/module-metadata/helpdesk/helpdesk-metadata.json`

**Important field flags**

- `department.name` — user key, unique  
- `category.name` — user key (required so Employee ticket form category search works)  

---

## 4. Department lifecycle (Institute pattern)

| Step | Who | Action |
| --- | --- | --- |
| 1 | Super Admin | Create department (name, description, portal prefix) → `InActive` |
| 2 | Super Admin | Create categories linked to that department |
| 3 | Helpdesk Agent | Open department → **Activate Department** → `Active` |
| 4 | Optional | Local DNS: hosts line for `it.helpdesk.ticket.com` (demo only) |

**Not in v1**

- Agent self-service “create my department” on signup  
- Employees restricted to categories of one department only (needs user→department assignment + extra record rules)  
- Separate portal app per department (Institute uses Nginx + Route53; helpdesk uses status + optional single hosts line)

---

## 5. UI flows

### Employee

1. **Helpdesk → Ticket** (list; only own rows).  
2. **Create** → form with title, description, status, **category**, priority, assignee/reporter.  
3. Track progress in list view.

### Helpdesk Agent

1. **Helpdesk → Ticket** → switch to **Kanban** (`groupBy: status`).  
2. Drag cards between columns; open form for detail.  
3. **Category** menu — maintain taxonomy.  
4. **Department** menu — open row → activate/deactivate on form header.  

### Super Admin

Same as agent plus department **create** and IAM.

---

## 6. Extension points

| Extension | Type | File / binding |
| --- | --- | --- |
| `TicketKanbanCardWidget` | `kanbanCardWidget` | `solid-ui/src/helpdesk/TicketKanbanCardWidget.tsx` |
| `ticketCriticalHandler` | `onFieldChange` | `ticket-form-view` → priority `Critical` → console alert |
| `departmentEditHandler` | `onFormLayoutLoad` | Shows activate vs deactivate by `status` |
| `DepartmentActivateById` / `DepartmentDeactivateById` | `formAction` | Popups; close via Redux `closePopup` |

**API (department)**

- `POST /api/department/activate/:id`  
- `POST /api/department/deactivate/:id`  
- Hosts write is best-effort: on failure, status still updates (`HELPDESK_SKIP_HOSTS` or permission errors do not block activation).

**Env (`solid-api/.env`)**

```env
HELPDESK_SKIP_HOSTS=true
HELPDESK_BASE_DOMAIN=helpdesk.ticket.com
HELPDESK_PORTAL_PORT=3002
```

---

## 7. Security

- **Permissions:** seeded per role in `helpdesk-metadata.json` → `roles[].permissions`.  
- **Record rule:** `model:ticket-role:Employee` → `createdBy == $activeUserId`.  
- **Menus:** each menu item lists `roles` or the sidebar is empty for Employee/Agent.  

**Test users (seeded)**

| Role | Username | Password |
| --- | --- | --- |
| Employee | `employee1` | `Helpdesk@123` |
| Helpdesk Agent | `agent1` | `Helpdesk@123` |
| Super Admin | `sa` | `Admin@3214$` |

---

## 8. Key repo paths

| Path | Role |
| --- | --- |
| `solid-api/module-metadata/helpdesk/helpdesk-metadata.json` | Models, views, roles, menus, security rules |
| `solid-api/src/helpdesk/` | Ticket, category, department controllers/services |
| `solid-ui/src/helpdesk/helpdesk.ui-module.ts` | Registers UI extensions |
| `solidx_helpdesk_tutorial.md` | Full build and test guide |
